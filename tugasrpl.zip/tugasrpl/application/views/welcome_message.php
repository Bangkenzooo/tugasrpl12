<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>tugas</title>
</head>

<body>
    <style>
    ul li {
        display: inline-block;
    }
    </style>

    <div>
        <table style="width:100%" border="1">
            <tr style="height: 88px; background:white;">
                <td style="text-align: center; font-weight:bold;">
                    Kelompok 5
                </td>
            </tr>
            <tr style="height: 5px; background:red;">
                <td>
                    <ul style="text-align: left;">
                        <li>home</li>
                        <li>galery</li>
                        <li>about</li>
                    </ul>
                </td>
            </tr>
            <tr style="height: 400px; background-color:green;">
                <td style="text-align: center; font-weight:bold; font-size:large;">
                    content
                </td>
            </tr>
            <tr style="height: 50px; background:blue;">
                <td style="text-align: center; font-weight:bold; font-size:large;">
                    footer
                </td>
            </tr>
        </table>
    </div>
</body>

</html>